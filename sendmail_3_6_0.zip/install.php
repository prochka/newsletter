<?php

////////////////////////////////////
// PHP Newsletter v3.6.0            
// (C) 2006-2013 Alexander Yanitsky 
// Website: http://janicky.com      
// E-mail: janickiy@mail.ru         
// Skype: janickiy                  
///////////////////////////////////

Error_Reporting(E_ALL & ~E_NOTICE);

if($_POST['language']) { $language = $_POST['language']; }
else { $language = 'ru'; }

$version = '3.6.0';

include "admin/templates/language/".$language."/language.inc";
include "admin/templates/language/".$language."/install.inc";

?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="StyleSheet" type="text/css" href="admin/style.css">
<title><?php echo TITLE; ?></title>
</head>
<body>
<script type="text/javascript">

function ChoiceLang(Lang)
{
	document.forms[0].setAttribute('action','<?php echo $_SERVER['PHP_SELF']; ?>');
	document.forms[0].submit();
}

function validate_form()
{
	valid = true;

	if(trim(document.forms[1].dblocation.value) == "")
	{
		alert("<?php echo MSG_ALERT; ?> '<?php echo DBLOCATION; ?>'!");
		valid = false;
	}

	if(trim(document.forms[1].dblogin.value) == "")
	{
		alert("<?php echo MSG_ALERT; ?> '<?php echo DBLOGIN; ?>'!");
		valid = false;
	}

	if(trim(document.forms[1].dbname.value) == "")
	{
		alert("<?php echo MSG_ALERT; ?> '<?php echo DBNAME; ?>'!");
		valid = false;
	}

	return valid;
}

function trim(str)
{
	var newstr = str.replace(/^\s*(.+?)\s*$/, "$1");

	if(newstr == " ")
	{
		return "";
	}

	return newstr;
}

</script>
<h1><?php echo TITLE_NAME; ?></h1>
<p>v <?php echo $version; ?></p>
<h2 style="text-align: center"><?php echo TITLE; ?></h2>
<br>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method=post>
  <table class="content" border="0">
	 <tr>
		<td><?php echo FORM_LANGUAGE; ?>: </td>
		<td><select type="text" onchange='ChoiceLang(this)'; class="input" name="language">
			 <option value="ru" <?php if($language == 'ru') echo 'selected'; ?>><?php echo FORM_LANGUAGE_RU; ?></option>
			 <option value="en" <?php if($language == 'en') echo 'selected'; ?>><?php echo FORM_LANGUAGE_EN; ?></option>
		  </select></td>
	 </tr>
  </table>
</form>
<p>*-<?php echo REQUIREDFIELD; ?></p>
<div class="tableform">
  <form action='<?php echo $_SERVER['PHP_SELF']; ?>' onsubmit="return validate_form();" method=post>
	 <table border="0">
		<tr>
		  <td><?php echo DBLOCATION; ?>*: </td>
		  <td><input type="text" name="dblocation" value='<?php if($_POST['dblocation']) echo $_POST['dblocation']; else echo "localhost"; ?>'></td>
		</tr>
		<tr>
		  <td><?php echo DBLOGIN; ?>*: </td>
		  <td><input type="text" name="dblogin" value='<?php echo $_POST['dblogin']; ?>'></td>
		</tr>
		<tr>
		  <td><?php echo DBPASSWD; ?>: </td>
		  <td><input type="text" name="dbpasswd" value='<?php echo $_POST['dbpasswd']; ?>'></td>
		</tr>
		<tr>
		  <td><?php echo DBNAME; ?>*: </td>
		  <td><input type="text" name="dbname" value='<?php echo $_POST['dbname']; ?>'></td>
		</tr>
		<tr>
		  <td><?php echo PREFIX; ?>: </td>
		  <td><input type="text" name="prefix" value='<?php if($_POST['prefix']) echo $_POST['prefix']; else echo "sm_"; ?>'></td>
		</tr>
		<tr>
		  <td><?php echo DBCHARSET; ?></td>
		  <td><input type="text" name="dbcharset" value='<?php if($_POST['dbcharset']) echo $_POST['dbcharset']; else echo "utf8"; ?>'></td>
		</tr>
		<tr>
		  <td><input class="button" type="submit" value="<?php echo FORM_CREATE; ?>"></td>
		</tr>
	 </table>
	 <input type=hidden name="language" value="<?php echo $language; ?>">
  </form>
</div>
<?php

if(!empty($_POST['dblocation']) &&
!empty($_POST['dblogin']) &&
!empty($_POST['dbname']))
{
	$_POST['dblocation'] = trim($_POST['dblocation']);
	$_POST['dblogin'] = trim($_POST['dblogin']);
	$_POST['dbpasswd'] = trim($_POST['dbpasswd']);
	$_POST['dbname'] = trim($_POST['dbname']);
	$_POST['prefix'] = trim($_POST['prefix']);
	$_POST['dbcharset'] = trim($_POST['dbcharset']);

	echo "<br><h2>".TITLE_NAME_2."</h2><ul>";

	$dbh = new mysqli($_POST['dblocation'], $_POST['dblogin'], $_POST['dbpasswd'], $_POST['dbname']);

	if(mysqli_connect_errno())
	{
		echo "<li>".MSG_UNABLE_CONNECT_TO_DB."</li>";
		echo '</ul>';
	}
	else
	{
		echo "<li>".MSG_CONNECTION_ESTABLISHED."</li>";
		echo "<li>".MSG_DB_CREATED."</li>";

		$dbh->query("SET NAMES '".$_POST['dbcharset']."'");

		$query[] = "CREATE TABLE IF NOT EXISTS `".$_POST['prefix']."aut` (
		`passw` VARCHAR( 32 ) NOT NULL
		) ENGINE=MyISAM";

		$query[] = "CREATE TABLE IF NOT EXISTS `".$_POST['prefix']."attach` (
		`id_attachment` int(7) NOT NULL AUTO_INCREMENT,
		`name` VARCHAR( 255 ) NOT NULL,
		`path` VARCHAR( 255 ) NOT NULL,
		`id_send` int(7) NOT NULL,
		PRIMARY KEY (id_attachment)
		) ENGINE=MyISAM DEFAULT CHARSET=utf8";

		$query[] = "INSERT INTO `".$_POST['prefix']."aut` VALUES ('b59c67bf196a4758191e42f76670ceba')";

		$query[] = "CREATE TABLE IF NOT EXISTS ".$_POST['prefix']."category (
		id_cat int(7) NOT NULL auto_increment,
		name VARCHAR( 200 ) NOT NULL,
		PRIMARY KEY  (id_cat)
		) ENGINE=MyISAM DEFAULT CHARSET=utf8";

		$query[] = "INSERT INTO `".$_POST['prefix']."category` VALUES (1, 'Category 1')";
		$query[] = "INSERT INTO `".$_POST['prefix']."category` VALUES (2, 'Category 2')";
		$query[] = "INSERT INTO `".$_POST['prefix']."category` VALUES (3, 'Category 3')";

		$query[] = "CREATE TABLE IF NOT EXISTS ".$_POST['prefix']."charset (
		`id_charset` int(5) NOT NULL AUTO_INCREMENT,
		`charset` VARCHAR( 32 ) NOT NULL,
		PRIMARY KEY (id_charset)
		) ENGINE=MyISAM";

		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (1, 'utf-8')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (2, 'iso-8859-1')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (3, 'iso-8859-2')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (4, 'iso-8859-3')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (5, 'iso-8859-4')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (6, 'iso-8859-5')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (7, 'iso-8859-6')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (8, 'iso-8859-8')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (9, 'iso-8859-7')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (10, 'iso-8859-9')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (11, 'iso-8859-10')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (12, 'iso-8859-13')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (13, 'iso-8859-14')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (14, 'iso-8859-15')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (15, 'iso-8859-16')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (16, 'windows-1250')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (17, 'windows-1251')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (18, 'windows-1252')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (19, 'windows-1253')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (20, 'windows-1254')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (21, 'windows-1255')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (22, 'windows-1256')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (23, 'windows-1257')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (24, 'windows-1258')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (25, 'gb2312')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (26, 'big5')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (27, 'iso-2022-jp')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (28, 'ks_c_5601-1987')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (29, 'euc-kr')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (30, 'windows-874')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (31, 'koi8-r')";
		$query[] = "INSERT INTO `".$_POST['prefix']."charset` VALUES (32, 'koi8-u')";

		$query[] = "CREATE TABLE IF NOT EXISTS `".$_POST['prefix']."log` (
		`id_log` int(7) NOT NULL AUTO_INCREMENT,
		`count` int(7) NOT NULL,
		`time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
		PRIMARY KEY (id_log)
		) ENGINE=MyISAM";

		$query[] = "CREATE TABLE IF NOT EXISTS `".$_POST['prefix']."ready_send` (
		`id_ready_send` int(10) NOT NULL AUTO_INCREMENT,
		`id_user` int(7) NOT NULL,
		`id_send` int(7) NOT NULL,
		PRIMARY KEY (`id_ready_send`),
		KEY `id_user` (`id_user`),
		KEY `id_send` (`id_send`)
		) ENGINE=MyISAM";

		$query[] = "CREATE TABLE IF NOT EXISTS `".$_POST['prefix']."send` (
		`id_send` int(7) NOT NULL AUTO_INCREMENT,
		`name` VARCHAR( 200 ) NOT NULL,
		`message` text NOT NULL,
		`prior` enum('1','2','3') NOT NULL DEFAULT '1',
		`date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
		`pos` int(7) NOT NULL,
		`id_cat` int(7) NOT NULL,
		`active` enum('yes','no') NOT NULL DEFAULT 'yes',
		PRIMARY KEY (id_send)
		) ENGINE=MyISAM DEFAULT CHARSET=utf8";

		$query[] = "CREATE TABLE IF NOT EXISTS `".$_POST['prefix']."settings` (
		`language` enum('en','ru') NOT NULL DEFAULT 'en',
		`count_send` int(4) NOT NULL DEFAULT '0',
		`count_user` int(4) NOT NULL DEFAULT '0',
		`email` VARCHAR( 200 ) NOT NULL,
		`organization` VARCHAR( 200 ) NOT NULL,
		`from_mail` VARCHAR( 200 ) NOT NULL,
		`smtp_host` VARCHAR( 200 ) NOT NULL,
		`smtp_username` VARCHAR( 200 ) NOT NULL,
		`smtp_password` VARCHAR( 200 ) NOT NULL,
		`smtp_port` int(8) NOT NULL DEFAULT '25',
		`smtp_aut` enum('1','2') NOT NULL DEFAULT '1',
		`smtp_ssl` enum('yes','no') NOT NULL DEFAULT 'no',
		`send_server` enum('1','2') NOT NULL,
		`id_charset` int(4) NOT NULL DEFAULT '0',
		`ContentType` enum('1','2') NOT NULL DEFAULT '1',
		`day` int(4) NOT NULL DEFAULT '0',
		`count_interval` int(6) NOT NULL DEFAULT '1',
		`send_limit` enum('yes','no') NOT NULL DEFAULT 'no',
		`smtp_timeout` int(6) NOT NULL DEFAULT '5',
		`limit_number` int(6) NOT NULL DEFAULT '100',
		`many_send` enum('yes','no') NOT NULL DEFAULT 'no',
		`del` enum('yes','no') NOT NULL DEFAULT 'yes',
		`show_email` enum('yes','no') NOT NULL DEFAULT 'yes',
		`newsubscribernotify` enum('yes','no') NOT NULL DEFAULT 'yes',
		`reply` enum('yes','no') NOT NULL DEFAULT 'no',
		`unsubscribe` enum('yes','no') NOT NULL,
		`subjecttextconfirm` VARCHAR( 200 ) NOT NULL,
		`textconfirmation` text NOT NULL,
		`unsublink` text NOT NULL,
		`interval_type` enum('no','m','h','d') NOT NULL DEFAULT 'no',
		`precedence` enum('no','bulk','junk','list') NOT NULL DEFAULT 'bulk'
		) ENGINE=MyISAM DEFAULT CHARSET=utf8";

		$query[] = "INSERT INTO `".$_POST['prefix']."settings` VALUES ('".$language."', 5, 20, 'admin@mysite.com', '', '', 'smtp.gmail.com', '', '', 25, '1', 'no', '1', 1, '2', 7, 1, 'yes', 5, 100, 'yes', 'yes', 'yes', 'no', 'no', 'yes', 'Подписка на рассылку', 'Здравствуйте, %NAME%\r\n\r\nПолучение рассылки возможно после завершения этапа активации подписки. У Вас %DAYS% дней, чтобы активировать подписку, перейдите по следующей ссылке: %CONFIRM%\r\nЕсли Вы не производили подписку на данный email, просто проигнорируйте это письмо или перейдите по ссылке: %UNSUB%\r\nС уважением, администратор сайта %SERVER_NAME%', 'Отписаться от рассылки: <a href=%UNSUB%>%UNSUB%</a>', 'no', 'bulk')";

		$query[] = "CREATE TABLE IF NOT EXISTS ".$_POST['prefix']."subscription (
		`id_sub` int(7) NOT NULL AUTO_INCREMENT,
		`id_user` int(10) NOT NULL,
		`id_cat` int(7) NOT NULL,
		PRIMARY KEY (`id_sub`),
		KEY `id_cat` (`id_cat`),
		KEY `id_user` (`id_user`)		
		) ENGINE=MyISAM";

		$query[] = "CREATE TABLE IF NOT EXISTS `".$_POST['prefix']."users` (
		`id_user` int(10) NOT NULL AUTO_INCREMENT,
		`name` VARCHAR( 200 ) NOT NULL,
		`email` VARCHAR( 200 ) NOT NULL,
		`ip` VARCHAR( 64 ) NOT NULL,
		`cod` VARCHAR( 64 ) NOT NULL,
		`time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
		`status` enum('active','noactive') NOT NULL DEFAULT 'noactive',
		`time_send` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
		PRIMARY KEY (id_user)
		) ENGINE=MyISAM DEFAULT CHARSET=utf8";

		$create_table = true;

		foreach($query as $value)
		{
			if(!@$dbh->query($value)) $create_table = false;
		}

		if($create_table == false)
		{
			echo "<li><span class=error>".MSG_FAILED_TO_CREATE_TABLES." ".$_POST['dbname']."! ".MSG_THEY_ALREADY_EXIST."</span></li>";
		}
		else echo "<li>".MSG_TABLE_SUCCESSFULLY_CREATED." ".$_POST['dbname']."...</li>";

		$string='<?php

$db_location = "'.$_POST['dblocation'].'"; // database host
$db_name = "'.$_POST['dbname'].'"; // database name
$db_user = "'.$_POST['dblogin'].'"; // login
$db_passwd = "'.$_POST['dbpasswd'].'"; // password
$db_charset = "'.$_POST['dbcharset'].'"; // database charset

$version = "'.$version.'";

$dbh = new mysqli($db_location, $db_user, $db_passwd, $db_name);

if(mysqli_connect_errno())
{
	error("Error connecting to MySQL database: Database server $db_location is not available!");
}

if(@file_exists("install.php") or @file_exists("../install.php"))
{
	error("Please remove install.php!");
}

$versql = $dbh->server_info;
list($major, $minor) = explode(".", $versql);
$ver = $major.".".$minor;

if((float)$ver >= 4.1 AND !empty($db_charset))
{
	$dbh->query("SET NAMES \'".$db_charset."\'");
}

define("DB_AUT","'.$_POST['prefix'].'aut");
define("DB_ATTACH","'.$_POST['prefix'].'attach");
define("DB_CAT","'.$_POST['prefix'].'category");
define("DB_CHAR","'.$_POST['prefix'].'charset");
define("DB_SETTING","'.$_POST['prefix'].'settings");
define("DB_SUB","'.$_POST['prefix'].'subscription");
define("DB_READY","'.$_POST['prefix'].'ready_send");
define("DB_SEND","'.$_POST['prefix'].'send");
define("DB_USERS","'.$_POST['prefix'].'users");
define("DB_LOG","'.$_POST['prefix'].'log");

define("CHARSET","utf-8");

?>';

		if(@is_writable("admin/lib/connect.inc"))
		{
			$f = @fopen("admin/lib/connect.inc","w");

			if(fwrite($f,$string) === FALSE)
			{
				echo "<li><span class=error>".MSG_ERROR_INSTALLATION_CANNOT_WRITE."</span></li></ul>";
				echo "<span class=error>".MSG_ERROR_INSTALLATION_CANNOT_WRITE_2."</span>";
			}
			else
			{
				echo "<li>".MSG_INSTALLATION_IS_COMPLETE."</li></ul>";
				echo "<span class=error>".MSG_INSTALLATION_IS_COMPLETE_2."</span>";
			}
			fclose($f);
		}
		else
		{
			echo "<li><span class=error>".MSG_ERROR_INSTALLATION_FILE_ISNT_WRITABLE."</li></ul>";
			echo "<span class=error>".MSG_ERROR_INSTALLATION_FILE_ISNT_WRITABLE_2."</span>";
		}
	}
}

?>
<p><?php echo LOGO; ?>, <?php echo AUTHOR; ?></p>
</body>
</html>
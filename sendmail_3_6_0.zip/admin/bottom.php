<?php

////////////////////////////////////
// PHP Newsletter v3.6.0            
// (C) 2006-2013 Alexander Yanitsky 
// Website: http://janicky.com      
// E-mail: janickiy@mail.ru         
// Skype: janickiy                  
///////////////////////////////////

?>
<br>
<table width="100%" border="0">
<tr>
	 <td width="50%"><p><?php echo LOGO; ?>, <?php echo AUTHOR; ?></p></td>
	 <td width="50%"><p align="right"><a href="faq.php">FAQ</a></p></td>
</tr>
</table>
</body>
</html>
